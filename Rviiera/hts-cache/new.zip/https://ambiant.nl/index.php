<!DOCTYPE html>
<html lang="nl">
<head>
    
<title>Ambiant heeft de PVC, vinyl, laminaat en tapijt vloer waarbij u zich thuis voelt</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="De Ambiant collectie bestaat uit laminaat, tapijt, vinyl en pvc vloeren collecties die volledig zijn afgestemd op uw wensen en de huidige woontrends. Voor elke woonstijl een vloer of om het anders te omschrijven, welk woonblad u ook leest"/>
<meta name="generator" content="concrete5"/>
<meta name="msapplication-TileImage" content="https://ambiant.nl/application/files/4515/1548/2653/favicon144.png"/>
<script type="text/javascript">
    var CCM_DISPATCHER_FILENAME = "/index.php";
    var CCM_CID = "208";
    var CCM_EDIT_MODE = false;
    var CCM_ARRANGE_MODE = false;
    var CCM_IMAGE_PATH = "/concrete/images";
    var CCM_TOOLS_PATH = "/index.php/tools/required";
    var CCM_APPLICATION_URL = "https://ambiant.nl";
    var CCM_REL = "";
</script>

<style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="168710" data-style-set="11">.ccm-custom-style-container.ccm-custom-style-main-168710{text-align:center}</style>
<link href="/concrete/css/font-awesome.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript" src="/concrete/js/jquery.js"></script>
<link href="/application/files/cache/css/687bcc9028f2df12c101d9e2b4e60c0efa05e9cf.css" rel="stylesheet" type="text/css" media="all" data-source="/concrete/css/jquery-ui.css /packages/revenew_toolkit/components/bootstrap/dist/css/bootstrap.min.css /packages/revenew_toolkit/components/jasny-bootstrap/dist/css/jasny-bootstrap.min.css /packages/revenew_toolkit/resources/jasny-bootstrap/fix/jasny-bootstrap.css /packages/revenew_toolkit/resources/bootstrap/responsive-rows-same-height/style.css /packages/revenew_newsletter/css/core-js.css">
<script type="text/javascript" src="/application/themes/ambiant/components/knockout/dist/knockout.js"></script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MHQX8FX');</script>
<!-- End Google Tag Manager -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-109836020-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-109836020-1');
</script>    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    
        <!-- Page Style -->
    <link href="/application/files/cache/css/ambiant/style.css" rel="stylesheet" type="text/css" media="all"></head>
<body class=" ">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MHQX8FX"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><div class="ccm-page page-wrapper">

    <!-- HEADER -->
    <header class="header fixed">

        <nav class="navbar navbar-default">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="usp-bar">

                                <div class="magestate">
                                    <ul>



                                        <li>
                                            <a href="https://ambiant.nl/catalogus/w/" title="wensenlijst" data-block="wishlist">
                                                <i class="fa fa-heart-o"></i>
                                                <span class="badge qty">0</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://ambiant.nl/catalogus/catalog/product_compare/index/" title="producten vergelijken" data-block='compare'>
                                                <span class="hidden">producten vergelijken</span>
                                                <i class="fa fa-random"></i>
                                                <span class="badge qty">0</span>
                                            </a>
                                        </li>

                                    </ul>
                                </div>

                            </div>
                        </div>
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">

                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="true">
                                <span class="sr-only">Menu</span>
                                <span class="icon-bar bar-top"></span>
                                <span class="icon-bar bar-mid"></span>
                                <span class="icon-bar bar-bot"></span>
                            </button>

                            <a class="navbar-brand" href="https://ambiant.nl/">
                                <img src="https://ambiant.nl/application/files/6115/6956/6156/Logo-ambiant.jpg" class="logo " alt="Logo"/>
                            </a>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">




                                <div class="row">

                                    <div class="col-sm-2 col-sm-push-10 no-pad custom-modification visible-sm">
                                        

    

    
<form id="top-search" action="https://ambiant.nl/catalogus/catalogsearch/result" accept-charset="UTF-8" method="get" role="search" class="headnav-search js-search">
    <input type="search" name="q" class="header-search form-control" placeholder="Waar ben je naar op zoek?"/>
    <a class="open-search" href="#" data-text="Zoeken"><span class="icon icon-search"></span></a>
</form>


                                    </div>

                                    <div class="col-sm-9 col-md-push-0 col-sm-offset-2 col-sm-pull-2 no-pad-right">
                                        <!-- Headermenu -->
                                        <ul class="nav navbar-nav header-navigation js-header">
                                            

    
<li class=""><a class="hidden-xs menu-homepage-link" href="https://ambiant.nl/" target="_self"><img src="/application/themes/ambiant/images/home.svg" alt="Go to Homepage"></a><a class="visible-xs" href="https://ambiant.nl/" target="_self">Home</a></li><li class=""><a href="https://ambiant.nl/catalogus/" target="_self">Alle vloeren</a></li><li class=""><a href="https://ambiant.nl/pvc/" target="_self">PVC</a></li><li class=""><a href="https://ambiant.nl/laminaat/" target="_self">Laminaat</a></li><li class=""><a href="https://ambiant.nl/tapijt/" target="_self">Tapijt</a></li><li class=""><a href="https://ambiant.nl/vinyl/" target="_self">Vinyl</a></li><li class=""><a href="https://ambiant.nl/traprenovatie/" target="_self">Traprenovatie</a></li><li class="with-submenu"><a href="https://ambiant.nl/concepten/" target="_self">Concepten</a><button type="button" name="drop-icon" class="drop-icon"></button><ul class="first-level"><li class=""><a href="https://ambiant.nl/concepten/silent-rigid-click/" target="_self">Silent Rigid Click</a></li></ul></li><li class=""><a href="https://cotap-ambiant.materialo.com/" target="_blank">Roomplanner</a></li><li class="with-submenu"><a href="https://ambiant.nl/over-ons/" target="_self">Over ons</a><button type="button" name="drop-icon" class="drop-icon"></button><ul class="first-level"><li class=""><a href="https://ambiant.nl/over-ons/blog/" target="_self">Blog</a></li></ul></li><li class="with-submenu"><a href="https://ambiant.nl/faq/" target="_self">Kennisbank</a><button type="button" name="drop-icon" class="drop-icon"></button><ul class="first-level"><li class=""><a href="https://ambiant.nl/faq/algemeen/" target="_self">Algemeen</a></li><li class=""><a href="https://ambiant.nl/faq/onderhoud/" target="_self">Onderhoud</a></li><li class=""><a href="https://ambiant.nl/faq/techniek/" target="_self">Techniek</a></li><li class=""><a href="https://ambiant.nl/faq/installatie/" target="_self">Installatie</a></li></ul></li>
                                        </ul>

                                        <!-- /Headermenu -->
                                    </div>

                                    <div class="col-sm-1 hidden-sm">
                                        

    

    
<form id="top-search" action="https://ambiant.nl/catalogus/catalogsearch/result" accept-charset="UTF-8" method="get" role="search" class="headnav-search js-search">
    <input type="search" name="q" class="header-search form-control" placeholder="Waar ben je naar op zoek?"/>
    <a class="open-search" href="#" data-text="Zoeken"><span class="icon icon-search"></span></a>
</form>


                                    </div>
                                </div>



                            </div><!-- /.navbar-collapse -->



                        </div>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </nav>



        <!-- Landing Header -->
                <!-- /Landing Header -->


    </header>
    <!-- /HEADER -->

    <!-- MAIN -->
    <main id="main" class="main">



    

    <!-- Header Slider -->
    <div class="sliderwrap">
        <div class="slider slick-slider">
                            <!--Header Slider -->
<div class="item header-slide" style="background-image:url(/application/files/images/cache/927a59dfb409ec6441cbfa77ecdf5fb3cd5c4cff.jpg);">
    <div class="slider-textblock">

        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6  col-md-push-6   white-text-color  touch-background">
                    <div class="half-container">
                        <div class="title">
                                                            <h2>PVC</h2>
                                                    </div>
                        <div class="subtitle">
                                                            <h2>De basis voor al uw mooie <br>woonmomenten</h2>
                                                    </div>
                                                    <a class="btn white-btn"
                               href="https://ambiant.nl/pvc/"  title="Ontdek meer">Ontdek meer</a>
                                            </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Header Slider -->                            <!--Header Slider -->
<div class="item header-slide" style="background-image:url(/application/files/images/cache/e8e98261413e719d727cabe587ab5fb786816bd8.jpg);">
    <div class="slider-textblock">

        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6  col-md-push-6   white-text-color  touch-background">
                    <div class="half-container">
                        <div class="title">
                                                            <h2>Vinyl</h2>
                                                    </div>
                        <div class="subtitle">
                                                            <h2>Trendy decors en naadloos.</h2>
                                                    </div>
                                                    <a class="btn white-btn"
                               href="https://ambiant.nl/vinyl/"  title="Ontdek meer">Ontdek meer</a>
                                            </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Header Slider -->                            <!--Header Slider -->
<div class="item header-slide" style="background-image:url(/application/files/images/cache/962ba2a83d3e2def210d3574a45dface630f9ed8.jpg);">
    <div class="slider-textblock">

        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6  col-md-push-6   white-text-color  touch-background">
                    <div class="half-container">
                        <div class="title">
                                                            <h2>Kamerbreed tapijt</h2>
                                                    </div>
                        <div class="subtitle">
                                                            <h2>Zacht, warm en uitnodigend.</h2>
                                                    </div>
                                                    <a class="btn white-btn"
                               href="https://ambiant.nl/tapijt/"  title="Ontdek meer">Ontdek meer</a>
                                            </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Header Slider -->                            <!--Header Slider -->
<div class="item header-slide" style="background-image:url(/application/files/images/cache/fc8279528b8ccb209a629f3902b44ac8434574c1.jpg);">
    <div class="slider-textblock">

        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6  col-md-push-6   white-text-color  touch-background">
                    <div class="half-container">
                        <div class="title">
                                                            <h2>Laminaat</h2>
                                                    </div>
                        <div class="subtitle">
                                                            <h2>Natuurgetrouw en betaalbaar!</h2>
                                                    </div>
                                                    <a class="btn white-btn"
                               href="https://ambiant.nl/laminaat/"  title="Ontdek meer">Ontdek meer</a>
                                            </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Header Slider -->                    </div>
        <a class="scroll-down js-scroll-1" data-scroll="Scroll"><i class="scroll-ico"></i></a>
    </div>
    <!-- /Header Slider -->





    <!--  Text Block -->
<section class="text-block">
    <div class="container">
        <div class="if-bgcolor">
            <div class="row">

                <div class="col-md-8 col-md-offset-2">
                    <div class="text-center">
                                                    <h1>Ambiant vloeren vindt u bij uw Ambiant dealer</h1>
                                            </div>
                </div>


                

                <div class="col-md-8 col-md-offset-2 text-center">
                                    </div>

            </div>
        </div>
    </div>
</section>
<!-- /Text Block -->



    
<!-- Multiteaser Block -->
<div class="multiteaser-block">
    <div class="container">
        <div class="row">

            <div class="col-sm-6">
                <div class="wrap-text" style="background-image:url(/application/files/images/cache/66cda7aa9040e6daa2ba691a1296b1d3f3813b35.jpg);">
                                            <div class="title">
                            <h2>PVC</h2>
                        </div>
                                                                <div class="subtitle">
                            <h3>Stil, sterk en duurzaam.</h3>
                        </div>
                                                                <div class="button-group">
                            <a class="btn white-btn" href="https://ambiant.nl/pvc/"  title="Ontdek Ambiant PVC vloeren">
                                Ontdek Ambiant PVC vloeren                            </a>
                        </div>
                                    </div>
            </div>

            <div class="col-sm-6">
                <div class="wrap-text" style="background-image:url(/application/files/images/cache/7751988ff4c1cfb96d5a128e9841d09b956619c4.jpg);">
                                            <div class="title">
                            <h2>Tapijt</h2>
                        </div>
                                                                <div class="subtitle">
                            <h3>Zacht, warm en uitnodigend.</h3>
                        </div>
                                                                <div class="button-group">
                            <a class="btn white-btn " href="https://ambiant.nl/tapijt/"  title="Ontdek Ambiant Tapijt">
                                Ontdek Ambiant Tapijt                            </a>
                        </div>
                                    </div>
            </div>

            <div class="col-sm-6">
                <div class="wrap-text" style="background-image:url(/application/files/images/cache/f509c6cebd8fbc6f650b9f57d3bd0fae8aba7189.jpg);">
                                            <div class="title">
                            <h2>Vinyl</h2>
                        </div>
                                                                <div class="subtitle">
                            <h3 class="subtitle">Trendy decors en naadloos.</h3>
                        </div>
                                                                <div class="button-group">
                            <a class="btn white-btn" href="https://ambiant.nl/vinyl/"  title="Ontdek Ambiant Vinyl">Ontdek Ambiant Vinyl</a>
                        </div>
                                     </div>
            </div>

            <div class="col-sm-6">
                 <div class="wrap-text" style="background-image:url(/application/files/images/cache/4f99f4bb27ef1042c1ccdd2e1b25ea1b3e1cf48a.jpg);">
                                            <div class="title">
                            <h2>Laminaat</h2>
                        </div>
                                                                <div class="subtitle">
                            <h2 class="subtitle">Natuurgetrouw en betaalbaar.</h2>
                        </div>
                                                                <div class="button-group">
                            <a class="btn white-btn" href="https://ambiant.nl/laminaat/"  title="Ontdek Ambiant laminaat">
                                Ontdek Ambiant laminaat                            </a>
                        </div>
                                    </div>
             </div>

        </div>
    </div>
</section>
<!-- /Multiteaser Block -->



    <!--  Text Block -->
<section class="text-block">
    <div class="container">
        <div class="if-bgcolor">
            <div class="row">

                <div class="col-md-8 col-md-offset-2">
                    <div class="text-center">
                                                    <h2>Onze vakmensen inspireren en creëren</h2>
                                            </div>
                </div>


                

                <div class="col-md-8 col-md-offset-2 text-center">
                                    </div>

            </div>
        </div>
    </div>
</section>
<!-- /Text Block -->



    

    <!-- Profesional Slider -->
    <section class="product-slider-wrap">
        <div class="container">
            <div class="slider product-slider">
                                    <!--Profesional Slider -->
<div class="item product-item">

        <a class="prod-item" href="https://ambiant.nl/over-ons/"  title="Betrokken advies">
                            <div class="lg-hexawrap">
                    <div class="product-img" style="background-image: url('/application/files/images/cache/cfdeec9bc28fa1d015788b31236d6bf64a23782c.jpg');"></div>
                </div>
                                        <div class="title">
                    <h2>Betrokken advies</h2>
                </div>
                                        <div class="content">
                    <p>In één ding zijn we ouderwets gebleven: service. Wanneer u wilt weten welke vloer bij uw woonwensen past staan onze Ambiant vloerenspecialisten klaar om u in een persoonlijk gesprek van praktisch advies en inspiratie te voorzien.<br></p>                </div>
                    </a>

</div>
<!--Profesional Slider -->                                    <!--Profesional Slider -->
<div class="item product-item">

        <a class="prod-item" href="https://ambiant.nl/over-ons/"  title="Gezondheid als prioriteit">
                            <div class="lg-hexawrap">
                    <div class="product-img" style="background-image: url('/application/files/images/cache/674c7a9de741c6f56ed5aef26ebaaa9638bba1d9.jpg');"></div>
                </div>
                                        <div class="title">
                    <h2>Gezondheid als prioriteit</h2>
                </div>
                                        <div class="content">
                    <p>Ambiant hecht zeer veel waarde aan uw gezondheid en het milieu. Zo is Ambiant pvc geheel ftalaatvrij en voorzien van biologische weekmakers. Geen vervuilende grondstoffen in uw vloer.</p>                </div>
                    </a>

</div>
<!--Profesional Slider -->                                    <!--Profesional Slider -->
<div class="item product-item">

        <a class="prod-item" href="https://ambiant.nl/over-ons/"  title="Gedreven vakkundigheid">
                            <div class="lg-hexawrap">
                    <div class="product-img" style="background-image: url('/application/files/images/cache/66dfe82135919cf91f0de84d37bb41bb2e00b03c.jpg');"></div>
                </div>
                                        <div class="title">
                    <h2>Gedreven vakkundigheid</h2>
                </div>
                                        <div class="content">
                    <p>De Ambiant collectie bestaat uit laminaat, tapijt, vinyl en pvc vloeren. Hoogwaardige collecties die volledig zijn afgestemd op uw wensen en de huidige woontrends.</p>                </div>
                    </a>

</div>
<!--Profesional Slider -->                                    <!--Profesional Slider -->
<div class="item product-item">

        <a class="prod-item" href="https://ambiant.nl/over-ons/"  title="Voor elke woonstijl">
                            <div class="lg-hexawrap">
                    <div class="product-img" style="background-image: url('/application/files/images/cache/ec25b2bc38373b7f41f964b1039688ee3ea6e790.jpg');"></div>
                </div>
                                        <div class="title">
                    <h2>Voor elke woonstijl</h2>
                </div>
                                        <div class="content">
                    <p>We zijn altijd op zoek naar de beste grondstoffen, designs en kwaliteit. Onze collectie is met smaak en oog voor detail uitgekozen en daardoor eigentijds, verrassend en stijlvol.</p>                </div>
                    </a>

</div>
<!--Profesional Slider -->                            </div>
        </div>
    </section>
    <!-- Profesional Slider -->




    

<!-- Brand Logo -->
<section class="brands-hexagon">
    <div class="slider brand-slider">

        
    </div>
</section>
<!-- /Brand Logo -->



    <!--  Text Block -->
<section class="text-block">
    <div class="container">
        <div class="if-bgcolor">
            <div class="row">

                <div class="col-md-8 col-md-offset-2">
                    <div class="text-center">
                                                    <h2>Vloerinspiratie nodig? Ambiant heeft het in huis!</h2>
                                            </div>
                </div>


                

                <div class="col-md-8 col-md-offset-2 text-center">
                                    </div>

            </div>
        </div>
    </div>
</section>
<!-- /Text Block -->



    

    <!-- Teaser Slider -->
    <section class="teaser-slider-wrap">
        <div class="container">
            <div class="row">
                <div class="slider teaser-slider">
                                            <!-- Teaser-slide-item -->
<div class="col-sm-12 col-md-6">
    <a class="item teaser-item js-sameHeight" href="https://ambiant.nl/over-ons/blog/"  title="Tips, ideeën en informatie lees je in onze blogs">

        <div class="col-xs-4 no-pad">
            <div class="teaser-hexa">
                                    <div class="teaser-cover"></div>
                    <img src="/application/files/images/cache/dcabc1d211ac3ceeecbdb8da2771dc030fe759d6.jpg" alt="Tips, ideeën en informatie lees je in onze blogs"/>
                            </div>
        </div>

        <div class="col-xs-8 no-pad">
            <div class="teaser-content">

                                    <div class="title">
                        <h2>Tips, ideeën en informatie lees ...</h2>
                    </div>
                
                                    <span class="js-overflow-elipsis"><p>Welke vloer legt u in uw woonruimte? Wat zijn de trends? Hoe onderhoudt u uw vloer? In onze blogs besteden we aandacht aan alles op het gebied van vloer en raam.</p></span>                
                                    <span class="btn-link" href="https://ambiant.nl/over-ons/blog/"  title="Naar blog">
                        Naar blog                        <span class="icon-right-open"></span>
                    </span>
                
            </div>
        </div>

    </a>
</div>
<!-- /Teaser-slide-item -->
                                            <!-- Teaser-slide-item -->
<div class="col-sm-12 col-md-6">
    <a class="item teaser-item js-sameHeight" href="https://ambiant.nl/afspraak-maken/"  title="Maak een afspraak voor deskundig advies">

        <div class="col-xs-4 no-pad">
            <div class="teaser-hexa">
                                    <div class="teaser-cover"></div>
                    <img src="/application/files/images/cache/0b1e319b3bf9052acd9d502a461466886e4a7b08.jpg" alt="Maak een afspraak voor deskundig advies"/>
                            </div>
        </div>

        <div class="col-xs-8 no-pad">
            <div class="teaser-content">

                                    <div class="title">
                        <h2>Maak een afspraak voor deskundig...</h2>
                    </div>
                
                                    <span class="js-overflow-elipsis"><p>Onze specialisten staan voor u klaar met goed advies voor uw raam en vloer.</p></span>                
                                    <span class="btn-link" href="https://ambiant.nl/afspraak-maken/"  title="Maak afspraak">
                        Maak afspraak                        <span class="icon-right-open"></span>
                    </span>
                
            </div>
        </div>

    </a>
</div>
<!-- /Teaser-slide-item -->
                                    </div>
            </div>
        </div>
    </section>
    <!--  /Teaser Slider -->


<div class="container video-holder  hidden ">
    <div class="row">
        <div class="col-xs-12">
            <div class="container-fluid video-holder-container">
                <div class="row">
                                    </div>
            </div>
        </div>
    </div>
</div>





            </main>
            <!-- /MAIN -->
            <!-- FOOTER -->
            <!-- Quick-Menu -->

            <footer>
                                    <section class="locator-wrap">
                        <!-- Dealer Locator-->
                        

    <!-- Dealer-Locator-Search -->
<section class="dealer-locator-search" style="background:transparent url('/application/files/images/cache/4a256aac3c4478d80b9e4e4c8e232f37d4222d1f.jpg') right no-repeat;">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">

                <form accept-charset="utf-8" class="form-inline" action="https://ambiant.nl/winkels/" >
                                            <div class="title">
                            <h2>Vind een Ambiant winkel en maak een afspraak</h2>
                        </div>
                                        <div class="location-wrap">
                        <input type="text" class="footerinput" id="input-postocode" placeholder="Postcode / plaats" name="address" value="">
                        <button type="submit" name="search-submit" class="search-submit"><i class="icon-search"></i><span></span></button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</section>
<!-- /Dealer-Locator-Search -->

                        <!-- /Dealer Locator -->
                    </section>
                                <section>
                    <div class="white-spaceholder">
                    </div>
                </section>

                <section class="link-block">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-md-4">
                                <!-- Site logo and social Link-->
                                

    

    
            <div class="social-wrap">
        <a class="logo-wrap" href="https://ambiant.nl/">
            <img src="https://ambiant.nl/application/files/6115/6956/6156/Logo-ambiant.jpg" class="img-responsive" alt="Logo"/>
        </a>
                <div class="block block-social">
            <h4 class="block-title">Volg ons</h4>
            <ul class="information">
                                                                                    <li><a href="https://www.instagram.com/ambiant.official/"target="_blank">
                            <img src="/application/themes/ambiant/images/instagram.svg" alt="Instagram">
                        </a></li>
                                                    <li><a href="https://nl.pinterest.com/cotapnl/"target="_blank">
                            <img src="/application/themes/ambiant/images/pinterest.svg" alt="Pinterest">
                        </a></li>
                
                                    <li><a href=" https://www.linkedin.com/company/10261734"target="_blank">
                            <img style="width:22px; height: 22px;" src="/application/themes/ambiant/images/linkedin.svg" alt="Pinterest">
                        </a></li>
                            </ul>
        </div>
            </div>
    



                                <!-- /Site logo-->
                            </div>
                            <div class="col-sm-12 col-md-4">
                                <!-- Newsletter -->
                                

        <div class="ccm-custom-style-container ccm-custom-style-main-168710" >
    <!-- Landing-btn -->
    <a class="btn-landing" href="https://ambiant.nl/nieuwsbrief/" target="">
        Schrijf je hier in voor de nieuwsbrief    </a>
<!-- /Landing-btn -->
    </div>


    
<div id="HTMLBlock164381" class="HTMLBlock">
<font size="1;">This site is protected by reCAPTCHA and the Google <a href="https://policies.google.com/privacy">Privacy Policy</a> and <a href="https://policies.google.com/terms">Terms of Service</a> apply.</font></div>
                                <!-- /Newsletter -->
                            </div>
                            <div class="col-sm-12 col-md-2 col-md-offset-1">
                                <!-- Footer menu -->
                                

        <address class="block block-contact-list" itemscope itemtype="http://schema.org/Organization">
        <ul class="block block-links">
            <li itemprop="streetAddress"> </li>
            <li itemprop="postalCode"></li>
            <li itemprop="addressLocality"></li>
            <li class="separator"></li>
            <li itemprop="telephone"></li>
        </ul>
    </address>
    
                                <!-- /Footer menu -->
                            </div>
                        </div>
                    </div>
                </section>

                <section class="copy-block">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <ul class="footer-copyright">
                                    <li>
                                        &copy; 2020 ambiant.nl
                                    </li>
                                    <li>
                                        

    

    

<ul class="list-inline">
    </ul>


                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>
                                    <div class="quick-menu js-quick-menu">

    
    <ul>
                <li class="text-pop-up no-popup">
            <a href="https://ambiant.nl/afspraak-maken/">
                <i class="ico icon-calendar-alt"></i>
                <div class="text">
                    AFSPRAAK MAKEN                </div>
            </a>
        </li>
                <li class="text-pop-up no-popup">
            <a href="https://ambiant.nl/winkels/">
                <i class="ico icon-map-marker-alt"></i>
                <div class='text'>
                    WINKEL                </div>
            </a>
        </li>
                            <li class="text-pop-up js-roomplanner-pop-up">
                <span class="popUp-span">Upload foto van uw vloer <i class="fa fa-angle-right"></i></span>
                <a href="https://ambiant.nl/bekijk-uw-vloer/">
                    <i class="ico icon-roomplanner"></i>
                    <div class="text">
                        BEKIJK UW VLOER                    </div>
                </a>
            </li>
        
            </ul>
    

</div>
                    <!-- /Quick-Menu -->
                            </footer>
            <!-- /FOOTER -->
            </div>
            <script type="text/javascript" src="/concrete/js/jquery-ui.js"></script>
<script type="text/javascript" src="/application/files/cache/js/2ad0a24b56a0a10f70641e7270370a96f1a36e8b.js" data-source="/ccm/assets/localization/jquery/ui/js/ /packages/revenew_toolkit/components/bootstrap/js/affix.js /packages/revenew_toolkit/components/bootstrap/js/carousel.js /packages/revenew_toolkit/components/bootstrap/js/collapse.js /packages/revenew_toolkit/components/bootstrap/js/modal.js /packages/revenew_toolkit/components/bootstrap/js/tab.js /concrete/js/bootstrap/tooltip.js /concrete/js/bootstrap/popover.js /packages/revenew_toolkit/components/bootstrap/js/scrollspy.js /concrete/js/bootstrap/dropdown.js /concrete/js/bootstrap/alert.js /concrete/js/bootstrap/button.js /concrete/js/bootstrap/transition.js /packages/revenew_toolkit/components/jasny-bootstrap/js/fileinput.js /packages/revenew_toolkit/components/jasny-bootstrap/js/inputmask.js /packages/revenew_toolkit/components/jasny-bootstrap/js/offcanvas.js /packages/revenew_toolkit/components/jasny-bootstrap/js/rowlink.js /packages/revenew_newsletter/js/jquery.form.min.js /packages/revenew_newsletter/js/core-js.js /concrete/js/underscore.js"></script>
<script type="text/javascript" src="//maps.google.com/maps/api/js?region=NL&language=nl&key=AIzaSyDpC7E_NV58aFroRni8Cw_u3Ps8YwUKXfQ"></script>
<script type="text/javascript" src="/application/files/cache/js/2b4977ac12355258e4872c0206baed350280ceb0.js" data-source="/concrete/../application/themes/ambiant/js/dealer_locator.js /packages/muntz_dealer_client/components/jquery.scrollintoview/jquery.scrollintoview.min.js /concrete/../application/themes/ambiant/js/custom.js /concrete/../application/themes/ambiant/js/jquery.cookie.js /concrete/../application/themes/ambiant/js/slick.js /concrete/../application/themes/ambiant/js/jquery.fancybox.min.js /application/blocks/brands_logo/view.js /application/blocks/dealerlocator_search/view.js /application/blocks/quick_menu/view.js"></script>

            <!-- Dealer search PopUp -->
                                                    <!-- /Dealer search PopUp -->

            <!-- Cookie disclaimer -->
                            

    


                        <!-- /Cookie disclaimer -->
    </body>
</html>

