<!doctype html>
<html lang="nl">
    <head >
        <script>
    var BASE_URL = 'https://ambiant.nl/catalogus/';
    var require = {
        "baseUrl": "https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL"
    };
</script>
        <meta charset="utf-8"/>
<meta name="title" content="404 Not Found"/>
<meta name="description" content="Page description"/>
<meta name="keywords" content="Page keywords"/>
<meta name="robots" content="INDEX,FOLLOW"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="format-detection" content="telephone=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title>404 Not Found</title>
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/mage/calendar.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/css/styles-m.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/css/yttheme.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/css/css_hack.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/css/brandlead.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Magento_Swatches/css/swatches.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Amasty_ShopbyBase/css/swiper.min.css" />
<link  rel="stylesheet" type="text/css"  media="screen and (min-width: 768px)" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/css/styles-l.css" />
<link  rel="stylesheet" type="text/css"  media="print" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/css/print.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Sm_InstagramGallery/css/instagramgallery.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Sm_InstagramGallery/css/owl.carousel.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Sm_InstagramGallery/css/animate.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Sm_InstagramGallery/css/jquery.fancybox.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Sm_InstagramGallery/helpers/jquery.fancybox-buttons.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/Sm_InstagramGallery/helpers/jquery.fancybox-thumbs.css" />
<link  rel="stylesheet" type="text/css"  media="all" href="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/mage/gallery/gallery.css" />
<script  type="text/javascript"  src="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/requirejs/require.js"></script>
<script  type="text/javascript"  src="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/mage/requirejs/mixins.js"></script>
<script  type="text/javascript"  src="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/requirejs-config.js"></script>
<script  type="text/javascript"  src="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/mage/polyfill.js"></script>
<link  rel="icon" type="image/x-icon" href="https://ambiant.nl/catalogus/media/favicon/stores/1/Logo-ambiant.jpg" />
<link  rel="shortcut icon" type="image/x-icon" href="https://ambiant.nl/catalogus/media/favicon/stores/1/Logo-ambiant.jpg" />
        <!-- BEGIN GOOGLE ANALYTICS CODE -->
<script type="text/x-magento-init">
{
    "*": {
        "Magento_GoogleAnalytics/js/google-analytics": {
            "isCookieRestrictionModeEnabled": 0,
            "currentWebsite": 1,
            "cookieName": "user_allowed_save_cookie",
            "ordersTrackingData": [],
            "pageTrackingData": {"optPageUrl":"","isAnonymizedIpActive":true,"accountId":"UA-109836020-1"}        }
    }
}
</script>
<!-- END GOOGLE ANALYTICS CODE -->

<!-- GOOGLE FONT BODY -->
		
		
	<!-- END GOOGLE FONT BODY -->

<!--CUSTOM JS-->


<!--LISTING CONFIG-->

<style>
	
@media (min-width: 1200px) {

	/*==1 COLUMN==*/
	
	.col1-layout .category-product.products-grid .item{
		width: 25%;
	}
	
	.col1-layout .category-product.products-grid .item:nth-child(4n+1){
		clear:both;
	}
	
	

	/*==2 COLUMNS==*/
	
	.col2-layout .category-product.products-grid .item{
		width: 33.333333333333%;
	}
	
	.col2-layout .category-product.products-grid .item:nth-child(3n+1){
		clear:both;
	}

	/*==3 COLUMNS==*/
	
	.col3-layout .category-product.products-grid .item{
		width: 33.333333333333%;
	}
	
	.col3-layout .category-product.products-grid .item:nth-child(3n+1){
		clear:both;
	}

}

@media (min-width: 992px) and (max-width: 1199px) {

	/*==1 COLUMN==*/
	
	.col1-layout .category-product.products-grid .item{
		width: 25%;
	}
	
	.col1-layout .category-product.products-grid .item:nth-child(4n+1){
		clear:both;
	}

	/*==2 COLUMNS==*/
	
	.col2-layout .category-product.products-grid .item{
		width: 33.333333333333%;
	}
	
	.col2-layout .category-product.products-grid .item:nth-child(3n+1){
		clear:both;
	}

	/*==3 COLUMNS==*/
	
	.col3-layout .category-product.products-grid .item{
		width: 33.333333333333%;
	}
	
	.col3-layout .category-product.products-grid .item:nth-child(3n+1){
		clear:both;
	}
}

@media (min-width: 768px) and (max-width: 991px) {

	/*==1 COLUMN==*/
	
	.col1-layout .category-product.products-grid .item{
		width: 33.333333333333%;
	}
	
	.col1-layout .category-product.products-grid .item:nth-child(3n+1){
		clear:both;
	}

	/*==2 COLUMNS==*/
	
	.col2-layout .category-product.products-grid .item{
		width: 50%;
	}
	
	.col2-layout .category-product.products-grid .item:nth-child(2n+1){
		clear:both;
	}

	/*==3 COLUMNS==*/
	
	.col3-layout .category-product.products-grid .item{
		width: 50%;
	}
	
	.col3-layout .category-product.products-grid .item:nth-child(2n+1){
		clear:both;
	}
}

@media (min-width: 481px) and (max-width: 767px) {

	/*==1 COLUMN==*/
	
	.col1-layout .category-product.products-grid .item{
		width: 50%;
	}
	
	.col1-layout .category-product.products-grid .item:nth-child(2n+1){
		clear:both;
	}

	/*==2 COLUMNS==*/
	
	.col2-layout .category-product.products-grid .item{
		width: 50%;
	}

	/*==3 COLUMNS==*/
	
	.col3-layout .category-product.products-grid .item{
		width: 50%;
	}
	
	.col3-layout .category-product.products-grid .item:nth-child(2n+1){
		clear:both;
	}
}

@media (max-width: 480px) {

	/*==1 COLUMN==*/
	
	.col1-layout .category-product.products-grid .item{
		width: 100%;
	}
	
	.col1-layout .category-product.products-grid .item:nth-child(1n+1){
		clear:both;
	}

	/*==2 COLUMNS==*/
	
	.col2-layout .category-product.products-grid .item{
		width: 100%;
	}
	
	.col2-layout .category-product.products-grid .item:nth-child(1n+1){
		clear:both;
	}

	/*==3 COLUMNS==*/
	
	.col3-layout .category-product.products-grid .item{
		width: 100%;
	}
	
	.col3-layout .category-product.products-grid .item:nth-child(1n+1){
		clear:both;
	}
}

</style>
<script type="text/javascript">
	require([
		'jquery',
		'jquerybootstrap',
		'owlcarousel',
		'jquerycookie',
		'jqueryfancyboxpack',
		'ytc_theme',
		'domReady!'
	], function ($) {

	});
	</script>

<style>
button, .checkout-container .authentication-wrapper button, .cart-summary .actions-toolbar > .primary button, .primary button, .btn-primary, .about-us .content-faq .panel .panel-title a::after, .about-us .content-faq .panel .panel-title a::before, #yt-totop, .footer .footer-top .about-us-footer img, .footer .footer-top .social-footer .socials-wrap ul li:hover a, .header-124 .minicart-header, .products-grid .item .item-inner .box-image .bottom-action-out .bottom-action .btn-action:hover, .product.media .fotorama__nav-wrap--horizontal .fotorama__thumb__arr--left .fotorama__thumb__arr:hover, .product.media .fotorama__nav-wrap--horizontal .fotorama__thumb__arr--right .fotorama__thumb__arr:hover, .products-list .item .item-inner .box-image-list .sm_quickview_handler:hover, .bottom-action-out .btn-action.btn-cart:hover, .minicart-wrapper .block-content > a.action:hover, .deal-wrapper-one .deals-time.time-day, .pagesdeal-wrapper .product_time, .pagesdeal-wrapper .title-home h2::after, .review-form .action.submit.primary, .btn-mobile .button-mobile, .cart-container .cart.main.actions .action, .cart-container .cart.table-wrapper .actions-toolbar .action-edit:hover, .cart-container .cart.table-wrapper .actions-toolbar .action-delete:hover, .footer .footer-middle .block .title::before, .header-container .cart-wrapper .showcart::before, .header-style-1 .header-middle .header-bottom-right .search-header-bottom .search-header-content, .sm-listing-tabs .ltabs-tabs-container .ltabs-tabs li.tab-sel::before, .sm-listing-tabs .ltabs-tabs-container .ltabs-tabs .ltabs-tab:hover::before, .cms-home-style-1 .title-home::before, .header-style-1 .search-header-content .actions button.action.search .info-box-detail .product-options-bottom .box-tocart .fieldset .actions button, .info-box-detail .product-add-form .box-tocart .fieldset .actions button, .title-view::before, .header-container .cart-wrapper .minicart-wrapper .block-content > .actions .viewcart:hover, .header-container .cart-wrapper .minicart-wrapper .block-content > .actions .checkout:hover, .login-container .block-customer-login a.action.create.primary, .login-container .action.primary, .header-124 .navigation-mobile-container, .cms-home-style-3 .item:hover a.shop-now, .home-style-4 .block-slider-basic-product .sm-basic-products .item-inner .btn-action.btn-cart:hover, .home-style-4 .block-slider-basic-product .sm-basic-products .item-inner .btn-action:hover, .home-style-4 .sm-listing-tabs .ltabs-items-container .owl-controls .owl-nav > div:hover, .home-style-4 .wrapper-banner4 .banner-home4.col-sm-4 .banner4 .content-bn a.shop-now:hover, .home-style-4 .sm-imageslider .item-info-slider .shop-now:hover, .home-style-4 .block-slider-basic-product .sm-basic-products .owl-nav > div:hover, .cms-home-style-4 .slider-blog4 .owl-nav > div:hover, .login-container .block-customer-login a.action.create.primary:hover, .login-container .block-new-customer a.action.create.primary:hover, .about-us .social-member .social-icon a:hover, .cart-container .cart.table-wrapper .actions-toolbar .action-edit:hover, .cart-container .cart.table-wrapper .actions-toolbar .action-delete:hover, .sm-imageslider a.shop-now:hover, .cms-home-style-3 .wapper-deals .deals-countdown .deals-time.time-day, .cms-home-style-3 .button-home3:hover, .cart.table-wrapper .actions-toolbar > .action:hover, .cart.table-wrapper .action-gift:hover, .products-list .item .item-inner .box-info-list .bottom-action form .btn-cart:hover, .cms-home-style-3 .block-title-home3 h2::before, .cms-home-style-3 .block-title-home3 h2::after, .cms-home-style-3 .sm-imageslider-inner.theme2 .owl-nav > div:hover , .cms-home-style-4 .sm-imageslider-inner.theme2 .owl-nav > div:hover , .cms-home-style-5 .sm-imageslider-inner.theme2 .owl-nav > div:hover, .detail-bottom-wrapper .product.data.items > .item.title:hover, .detail-bottom-wrapper .product.data.items > .item.title.active,  .navigation-container.css-menu-wrap, .addthis_button_twitter:hover, .addthis_button_facebook:hover, .addthis_button_pinterest_share:hover, .addthis_button_google_plusone_share:hover, .addthis_button_email:hover {
	background: #000;
}

.color_theme, .header-124 .header-top .dropdown-block:hover .dropdown-toggle a, .header-124 .header-top .dropdown-block:hover .dropdown-toggle .value, .header-124 .header-top .dropdown-block .dropdown-list a:hover, .breadcrumbs ul li:last-child strong, .footer .footer-middle .block .content > p.email a:hover, .footer .footer-middle .block .content ul li a:hover, .footer .footer-middle .block.ft-category .content ul li a:hover, .cms-index-index .header-container .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li.home-item-parent > a, .footer .footer-middle .block.ft-category .content ul li a::after, .home-menu-dropdown .item-home-store li a:hover, .header-container .cart-wrapper .minicart-wrapper .block-content .minicart-items-wrapper .minicart-items .product-item-details .product-item-name a:hover, .header-container .switcher .dropdown .switcher-trigger strong:hover, .header-container .dropdown .dropdown-toggle > a:hover, .header-container .dropdown .mage-dropdown-dialog a:hover, .header-container .dropdown .mage-dropdown-dialog .current, .header-container .dropdown:hover .dropdown-toggle a, .header-container .dropdown:hover .dropdown-toggle .value, .header-container .dropdown.block-base .links li a::after, .header-style-1 .header-top .dropdown-block:hover .dropdown-toggle a, .header-style-1 .header-top .dropdown-block:hover .dropdown-toggle .value, .header-style-1 .header-top .dropdown-block .dropdown-list a:hover .header-container .dropdown-block-custom.block-base .links li a::after,
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu li:hover a.sm_megamenu_head, 
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu li:hover a.sm_megamenu_head .sm_megamenu_icon::before, 
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu_black li:hover div a:hover, 
.header35 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu li:hover > a.sm_megamenu_head,
.header35 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu li:hover > a.sm_megamenu_head:after,
.header35 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu li.sm_megamenu_actived > a.sm_megamenu_head,
.header35 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu li.sm_megamenu_actived > a:after, 
.header35 .css-menu-wrap .navigation > .ui-menu > li:hover > a,.sm_megamenu_wrapper_horizontal_menu  .sm-megamenu-child .sm_megamenu_title a.sm_megamenu_actived,
.header35 .css-menu-wrap .navigation > .ui-menu > li.active > a, 
.cms-index-index .header35 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu li:first-child a.sm_megamenu_head ,
.sm-megamenu-child .sm_megamenu_title > a:hover, .socials-wrap a:hover, 
.cms-index-index .header-style-2 .header-middle .menu-under .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li:first-child > a, 
.header-style-2 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li.sm_megamenu_actived > a:after, 
.header-style-2 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li:hover > a:after,
.header-style-2 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li.sm_megamenu_actived > a, .header-style-2 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li:hover > a,
.cms-index-index .header-style-2 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu li:first-child a.sm_megamenu_head,
.latest-post-block .slider-latest-blog .slider-blog .item .blog-item-content .info-blog .action-post .btn-readmore, 
.block .block-content .filter-options-content .items li a:hover, 
.products-grid .item .item-inner .box-info .product-name a:hover, 
.toolbar .pages .pages-items .item.current strong, 
.toolbar .pages .pages-items .item a:hover, 
.header-container .cart-wrapper .minicart-wrapper .block-minicart .amount .price-wrapper:first-child .price, 
.cms-home-style-2.cms-index-index .slide-img .item .infoslide.col-right h3, 
.deal-wrapper-one .timer-deal1 .timer-product .deals-time, 
.header-style-2 a.page-daydeals, 
.cms-home-style-3 .latest-post-home3 .postDate, 
.cms-home-style-3 .latest-post-home3 .item::before, 
.header-style-2 .css-menu-wrap .navigation > .ui-menu > li:hover > a, 
.header-style-2 .css-menu-wrap .navigation > .ui-menu > li.active > a, 
.sm_megamenu_wrapper_horizontal_menu .sambar-inner .sm_megamenu_menu > li > div .sm_megamenu_actived > a,
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu .sm_megamenu_top_actived > a,
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu .sm_megamenu_actived > a,
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu .sm_megamenu_top_actived span.sm_megamenu_icon:before,
.sm_megamenu_wrapper_vertical_menu .sm_megamenu_menu .sm_megamenu_actived span.sm_megamenu_icon:before
{
	color: #000;
}

.owl-theme .owl-dots .owl-dot:hover span, .owl-theme .owl-dots .owl-dot.active span, .cart-container .cart.table-wrapper .actions-toolbar .action-edit:hover, .cart-container .cart.table-wrapper .actions-toolbar .action-delete:hover, .about-us .about-image-slider .owl-controls .owl-nav div:hover, .footer .footer-top .social-footer .socials-wrap ul li:hover a, .header-style-1 .header-bottom .nav-mobile-container .btn-mobile .button-mobile, .products-grid .item .item-inner .box-image .bottom-action-out .bottom-action .btn-action:hover, .sm-super-categories .category-wrap .banner-c-brand .brand ul li a:hover, .brand-block .list-brands li a:hover, .block-collapsible-nav .item.current a, .block-collapsible-nav .item.current strong, .products-list .item .item-inner .box-image-list .sm_quickview_handler:hover ,.cms-home-style-3   .item:hover a.shop-now , .home-style-4 .block-slider-basic-product .sm-basic-products .item-inner .btn-action.btn-cart:hover , .home-style-4 .block-slider-basic-product .sm-basic-products .item-inner .btn-action:hover , .home-style-4 .wrapper-banner4 .banner-home4.col-sm-4 .banner4 .content-bn a.shop-now:hover , .home-style-4 .sm-imageslider .item-info-slider .shop-now:hover , .fotorama-item .fotorama__nav--thumbs .fotorama__nav__frame.fotorama__active , .sm-imageslider a.shop-now:hover , .cms-home-style-3 .button-home3:hover , .cms-home-style-3 .wapper-deals .deals-countdown .deals-time ,.cart.table-wrapper .actions-toolbar > .action:hover, .cart.table-wrapper .action-gift:hover, .addthis_button_twitter:hover, .addthis_button_facebook:hover, .addthis_button_pinterest_share:hover, .addthis_button_google_plusone_share:hover, .addthis_button_email:hover, .header-container .cart-wrapper .minicart-wrapper .block-content > .actions .viewcart:hover, .header-container .cart-wrapper .minicart-wrapper .block-content > .actions .checkout:hover, .cart-container .cart.main.actions .action:hover{
	border-color: #000;
}



.footer .footer-middle .block .content > p.email a:hover,
.latest-post-block .slider-latest-blog .slider-blog .item .blog-item-content .info-blog .action-post .btn-readmore:hover,
.header-style-2 .header-bottom .header-bottom-right .search-header-bottom .search-header-content .actions:hover button.action.search:before {
	color: #000;
}


#yt-totop:hover,
.info-box-detail .product-options-bottom .box-tocart .fieldset .actions button:hover, .info-box-detail .product-add-form .box-tocart .fieldset .actions button:hover, .products-grid .item .item-inner .box-image .bottom-action-out .bottom-action .btn-action.btn-cart:hover , .toolbar .modes .mode-grid.active:before, .toolbar .modes .mode-grid:hover:before , .toolbar .modes .mode-list.active:before, .toolbar .modes .mode-list:hover:before, .cart-container .cart.main.actions .action:hover,
button:hover, .cart.table-wrapper .actions-toolbar > .action:hover, .cart.table-wrapper .action-gift:hover{
	background-color: #000;
}

.header-container .cart-wrapper .minicart-wrapper .block-content  .action:hover, .products-grid .item .item-inner .box-image .bottom-action-out .bottom-action .btn-action.btn-cart:hover, .cms-home-style-5 .sm-listing-tabs .ltabs-tabs-container li.ltabs-tab:hover, .cms-home-style-5 .sm-listing-tabs .ltabs-tabs-container li.ltabs-tab.tab-sel , .product.data.items > .item.content {
	border-color: #000;
}

/*--begin header--*/
.header-124 .sm_megamenu_wrapper_horizontal_menu .sambar-inner, .cms-home-style-5 .sm-listing-tabs .ltabs-tabs-container li.ltabs-tab:hover, .cms-home-style-5 .sm-listing-tabs .ltabs-tabs-container li.ltabs-tab.tab-sel, .cms-home-style-5 .category-img .col-sm-3 .conten-cat .button-cate:hover, .cms-home-style-5 .sm-listing-tabs .tab-listing-title::after, .cms-home-style-5 .block-subscribe .block-content .input-box button {
	background-color: #000;
}
.cms-home-style-5 .sm-listing-tabs .ltabs-tabs-container li.ltabs-tab:hover, .cms-home-style-5 .sm-listing-tabs .ltabs-tabs-container li.ltabs-tab.tab-sel {
	outline: 1px solid #000;
}

/*--end header--*/
/*--other--*/
.price-box .price, .header-style-2 .sm_megamenu_wrapper_horizontal_menu .sm_megamenu_menu > li > a:hover, .header-style-3 .form.minisearch button::before, .owl-controls .owl-nav div:hover::before, .rating-summary .rating-result > span::before, .info-box-detail .product-info-stock-sku .available::after, .control-qty .quantity-controls:hover , .cms-home-style-2.cms-index-index .wrapper-brandsdivde .brand-slider .owl-nav > div:before {
	color: #000;
}
.block .block-content .filter-options-title::after, .bg-button:hover, .sm_megamenu_wrapper_vertical_menu .block-title, .header-124 .search-header-bottom .search-header-content .actions button.action.search, .wrapper-slider-blog4 .slider-blog4 .item-inner .image-blog .postDate, .home-style-4 .block-slider-basic-product .basicproducts_title_text::after, .home-style-4 .sm-listing-tabs .tab-listing-title::before, .home-style-4 .sm-listing-tabs .tab-listing-title::after, .home-style-4 .sm-listing-tabs .ltabs-tabs-container ul li.tab-sel, .home-style-4 .sm-listing-tabs .ltabs-tabs-container ul li:hover, .wrapper-slider-blog45 .title-home-blog h2::after, .wrapper-slider-blog45 .title-home-blog h2::after, .wrapper-slider-blog45 .slider-blog4 .item-inner .image-blog .postDate, .info-box-detail .product-add-form .box-tocart .fieldset .actions button {
	background-color: #000;
}
.bg-button:hover  , .sm_megamenu_wrapper_vertical_menu .sm_megamenu_drop > div , .home-style-1 .testimonials .margin-slider .image-client , .header-style-2 .header-bottom , .home-style-4 .testimonials-home .testimonials-slider .owl-item.active.center .image-client img{
	border-color: #000;
}
.bg-button:hover:before , .home-style-1 .block-subscribe .button:before , .minicart-items .product-item-details .price {
	color: #000;
}
/*--footer--*/
.copyright .copyright-footer a , .footer .footer-middle .block .content ul li span.label-bt, .footer .footer-middle .container_instagramusers .content ul li span.label-bt   {
	color: #000;
}
.footer .footer-middle .block .title::before, .footer .footer-middle .container_instagramusers .title::before, .footer .footer-middle .block .block-title::before, .footer .footer-middle .container_instagramusers .block-title::before {
	background-color:#000 ;
}
/*--end footer---*/
/*index 2*/
.product-basic3 .product-basic-home2 .sm-basic-products .categories-pro .fa  {
	background-color: #000;
}
.product-basic3 .product-basic-home2 .sm-basic-products .categories-pro h2 , .product-basic3 .product-basic-home2 .sm-basic-products .categories-pro ul li a:hover{
	color: #000;
}
/*page blog*/
.pageblog .postTitle .postDate {
	background-color:#000;
}
.label-product.label-sale::before {
	border: 13px solid  #000;
	border-right-color: rgba(255,255,255,0);
      left:0px;
}
@media (max-width: 991px) {
	.header-style-3 .btn-mobile .button-mobile.active {
		color: #000;
	}	
}
</style><script>
    require.config({
        map: {
            '*': {
                'quickSearch-original' : 'Magento_Search/js/form-mini',
                'quickSearch' : 'Amasty_Xsearch/js/form-mini'
            }
        }
    });
</script>
    </head>
    <body data-container="body"
          data-mage-init='{"loaderAjax": {}, "loader": { "icon": "https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/images/loader-2.gif"}}'
        class="brandlead cms-no-route cms-noroute-index page-layout-2columns-right">
        
<script>
    var CONCRETE_BASE_URL = "https:\/\/ambiant.nl\/";
</script>

<script type="text/x-magento-init">
    {
        "*": {
            "mage/cookies": {
                "expires": null,
                "path": "\u002Fcatalogus",
                "domain": ".ambiant.nl",
                "secure": false,
                "lifetime": "3600"
            }
        }
    }
</script>
    <noscript>
        <div class="message global noscript">
            <div class="content">
                <p>
                    <strong>JavaScript lijkt te zijn uitgeschakeld in uw browser.</strong>
                    <span>Voor de beste gebruikerservaring, zorg ervoor dat javascript ingeschakeld is voor uw browser.</span>
                </p>
            </div>
        </div>
    </noscript>

<script>
    window.cookiesConfig = window.cookiesConfig || {};
    window.cookiesConfig.secure = true;
</script>
<script>
    require.config({
        map: {
            '*': {
                wysiwygAdapter: 'mage/adminhtml/wysiwyg/tiny_mce/tinymce4Adapter'
            }
        }
    });
</script>

<div class="page-wrapper"><header class="page-header">
<!-- HEADER -->
<header class="header fixed">

    <nav class="navbar navbar-default">
        <div class="container">
            <div class="row">

                <div class="col-sm-12">

                    <div class="usp-bar">
                        <div class="magestate custom-modification">
                            <ul>
                                <li data-bind="scope: 'simpleWishlist'" data-block="wishlist">
                                    <a data-bind="css: {'hidden': !count()}" class="wishlist hidden" href="https&#x3A;&#x2F;&#x2F;ambiant.nl&#x2F;catalogus&#x2F;w&#x2F;" title="wensenlijst">
                                        <i class="icon fa fa-heart-o"></i>
                                        <span class="badge qty" data-bind="text: count()">0</span>
                                    </a>
                                    <script type="text/x-magento-init">
                                        {
                                            "[data-block='wishlist']": {
                                                "Magento_Ui/js/core/app": {
                                                    "components": {
                                                        "simpleWishlist": {
                                                            "component": "Muntz_SimpleWishlist/js/view/wishlist"
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    </script>
                                </li>

                                <li data-bind="scope: 'compareProducts'" data-role="compare-products-link" data-block='compare'>
                                    <a data-bind="attr: {'href': compareProducts().listUrl}, css: {'hidden': !compareProducts().count}" class="hidden" title="producten vergelijken">
                                        <i class="fa fa-random"></i>
                                        <span class="badge qty" data-bind="text: compareProducts().count">0</span>
                                    </a>

                                    <script type="text/x-magento-init">
                                        {
                                            "[data-role=compare-products-link]": {
                                                "Magento_Ui/js/core/app": {"components":{"compareProducts":{"component":"Magento_Catalog\/js\/view\/compare-products"}}}                                            }
                                        }
                                    </script>
                                </li>

                            </ul>
                        </div>
                    </div>

                </div>

                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="true">
                        <span class="sr-only">Menu</span>
                        <span class="icon-bar bar-top"></span>
                        <span class="icon-bar bar-mid"></span>
                        <span class="icon-bar bar-bot"></span>
                    </button>

                    <a class="navbar-brand" href="/">
                        <img src="https://ambiant.nl/catalogus/static/version1599472374/frontend/Muntz/ambiant/nl_NL/images/logo.png" class="logo" alt="Logo"/>
                    </a>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <div class="row">

                            <div class="col-sm-2 col-sm-push-10 no-pad custom-modification visible-sm">
                                

    

    
<form id="top-search" action="https://ambiant.nl/catalogus/catalogsearch/result" accept-charset="UTF-8" method="get" role="search" class="headnav-search js-search">
    <input type="search" name="q" class="header-search form-control" placeholder="Waar ben je naar op zoek?"/>
    <a class="open-search" href="#" data-text="Zoeken"><span class="icon icon-search"></span></a>
</form>


                            </div>

                            <div class="col-sm-9 col-md-push-0 col-sm-offset-2 col-sm-pull-2 no-pad-right">
                                <!-- Headermenu -->
                                <ul class="nav navbar-nav header-navigation js-header">
                                    

    
<li class=""><a class="hidden-xs menu-homepage-link" href="https://ambiant.nl/" target="_self"><img src="/application/themes/ambiant/images/home.svg" alt="Go to Homepage"></a><a class="visible-xs" href="https://ambiant.nl/" target="_self">Home</a></li><li class=""><a href="https://ambiant.nl/catalogus/" target="_self">Alle vloeren</a></li><li class=""><a href="https://ambiant.nl/pvc/" target="_self">PVC</a></li><li class=""><a href="https://ambiant.nl/laminaat/" target="_self">Laminaat</a></li><li class=""><a href="https://ambiant.nl/tapijt/" target="_self">Tapijt</a></li><li class=""><a href="https://ambiant.nl/vinyl/" target="_self">Vinyl</a></li><li class=""><a href="https://ambiant.nl/traprenovatie/" target="_self">Traprenovatie</a></li><li class="with-submenu"><a href="https://ambiant.nl/concepten/" target="_self">Concepten</a><button type="button" name="drop-icon" class="drop-icon"></button><ul class="first-level"><li class=""><a href="https://ambiant.nl/concepten/silent-rigid-click/" target="_self">Silent Rigid Click</a></li></ul></li><li class=""><a href="https://cotap-ambiant.materialo.com/" target="_blank">Roomplanner</a></li><li class="with-submenu"><a href="https://ambiant.nl/over-ons/" target="_self">Over ons</a><button type="button" name="drop-icon" class="drop-icon"></button><ul class="first-level"><li class=""><a href="https://ambiant.nl/over-ons/blog/" target="_self">Blog</a></li></ul></li><li class="with-submenu"><a href="https://ambiant.nl/faq/" target="_self">Kennisbank</a><button type="button" name="drop-icon" class="drop-icon"></button><ul class="first-level"><li class=""><a href="https://ambiant.nl/faq/algemeen/" target="_self">Algemeen</a></li><li class=""><a href="https://ambiant.nl/faq/onderhoud/" target="_self">Onderhoud</a></li><li class=""><a href="https://ambiant.nl/faq/techniek/" target="_self">Techniek</a></li><li class=""><a href="https://ambiant.nl/faq/installatie/" target="_self">Installatie</a></li></ul></li>
                                </ul>
                                <!-- /Headermenu -->
                            </div>
                            <!-- Header-Search -->
                            <div class="col-sm-1 hidden-sm">
                                

    

    
<form id="top-search" action="https://ambiant.nl/catalogus/catalogsearch/result" accept-charset="UTF-8" method="get" role="search" class="headnav-search js-search">
    <input type="search" name="q" class="header-search form-control" placeholder="Waar ben je naar op zoek?"/>
    <a class="open-search" href="#" data-text="Zoeken"><span class="icon icon-search"></span></a>
</form>


                            </div>
                            <!-- /Header-Search -->
                        </div>
                    </div><!-- /.navbar-collapse -->

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </nav>
    <!-- Quick-Menu -->
    <div class="quick-menu js-quick-menu">
        

    
    <ul>
                <li class="text-pop-up no-popup">
            <a href="https://ambiant.nl/afspraak-maken/">
                <i class="ico icon-calendar-alt"></i>
                <div class="text">
                    AFSPRAAK MAKEN                </div>
            </a>
        </li>
                <li class="text-pop-up no-popup">
            <a href="https://ambiant.nl/winkels/">
                <i class="ico icon-map-marker-alt"></i>
                <div class='text'>
                    WINKEL                </div>
            </a>
        </li>
                            <li class="text-pop-up js-roomplanner-pop-up">
                <span class="popUp-span">Upload foto van uw vloer <i class="fa fa-angle-right"></i></span>
                <a href="https://ambiant.nl/bekijk-uw-vloer/">
                    <i class="ico icon-roomplanner"></i>
                    <div class="text">
                        BEKIJK UW VLOER                    </div>
                </a>
            </li>
        
            </ul>
    

    </div>
    <!-- /Quick-Menu -->
</header>
<!-- /HEADER -->

</header><main id="maincontent" class="page-main"><a id="contentarea" tabindex="-1"></a>
<div class="columns col2-layout"><div class="container"><div class="row"><div class="col-lg-9 col-md-9"><div class="page-title-wrapper">
    <h1 class="page-title"
                >
        <span class="base" data-ui-id="page-title-wrapper" >Whoops, our bad...</span>    </h1>
    </div>
<div class="page messages"><div data-placeholder="messages"></div>
<div data-bind="scope: 'messages'">
    <!-- ko if: cookieMessages && cookieMessages.length > 0 -->
    <div role="alert" data-bind="foreach: { data: cookieMessages, as: 'message' }" class="messages">
        <div data-bind="attr: {
            class: 'message-' + message.type + ' ' + message.type + ' message',
            'data-ui-id': 'message-' + message.type
        }">
            <div data-bind="html: $parent.prepareMessageForHtml(message.text)"></div>
        </div>
    </div>
    <!-- /ko -->

    <!-- ko if: messages().messages && messages().messages.length > 0 -->
    <div role="alert" data-bind="foreach: { data: messages().messages, as: 'message' }" class="messages">
        <div data-bind="attr: {
            class: 'message-' + message.type + ' ' + message.type + ' message',
            'data-ui-id': 'message-' + message.type
        }">
            <div data-bind="html: $parent.prepareMessageForHtml(message.text)"></div>
        </div>
    </div>
    <!-- /ko -->
</div>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Ui/js/core/app": {
                "components": {
                        "messages": {
                            "component": "Magento_Theme/js/view/messages"
                        }
                    }
                }
            }
    }
</script>
</div><div class="column main"><input name="form_key" type="hidden" value="wYz1TjRUjn3xqHbD" /><div id="authenticationPopup" data-bind="scope:'authenticationPopup'" style="display: none;">
    <script>
        window.authenticationPopup = {"autocomplete":"off","customerRegisterUrl":"https:\/\/ambiant.nl\/catalogus\/customer\/account\/create\/","customerForgotPasswordUrl":"https:\/\/ambiant.nl\/catalogus\/customer\/account\/forgotpassword\/","baseUrl":"https:\/\/ambiant.nl\/catalogus\/"};
    </script>
    <!-- ko template: getTemplate() --><!-- /ko -->
    <script type="text/x-magento-init">
        {
            "#authenticationPopup": {
                "Magento_Ui/js/core/app": {"components":{"authenticationPopup":{"component":"Magento_Customer\/js\/view\/authentication-popup","children":{"messages":{"component":"Magento_Ui\/js\/view\/messages","displayArea":"messages"},"captcha":{"component":"Magento_Captcha\/js\/view\/checkout\/loginCaptcha","displayArea":"additional-login-form-fields","formId":"user_login","configSource":"checkout"},"amazon-button":{"component":"Amazon_Login\/js\/view\/login-button-wrapper","sortOrder":"0","displayArea":"additional-login-form-fields","config":{"tooltip":"Securely login into our website using your existing Amazon details.","componentDisabled":true}}}}}}            },
            "*": {
                "Magento_Ui/js/block-loader": "https\u003A\u002F\u002Fambiant.nl\u002Fcatalogus\u002Fstatic\u002Fversion1599472374\u002Ffrontend\u002FMuntz\u002Fambiant\u002Fnl_NL\u002Fimages\u002Floader\u002D1.gif"
            }
        }
    </script>
</div>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/section-config": {
                "sections": {"stores\/store\/switch":["*"],"stores\/store\/switchrequest":["*"],"directory\/currency\/switch":["*"],"*":["messages"],"customer\/account\/logout":["*","recently_viewed_product","recently_compared_product","persistent"],"customer\/account\/loginpost":["*"],"customer\/account\/createpost":["*"],"customer\/account\/editpost":["*"],"customer\/ajax\/login":["checkout-data","cart","captcha"],"catalog\/product_compare\/add":["compare-products"],"catalog\/product_compare\/remove":["compare-products"],"catalog\/product_compare\/clear":["compare-products"],"sales\/guest\/reorder":["cart"],"sales\/order\/reorder":["cart"],"checkout\/cart\/add":["cart","directory-data"],"checkout\/cart\/delete":["cart"],"checkout\/cart\/updatepost":["cart"],"checkout\/cart\/updateitemoptions":["cart"],"checkout\/cart\/couponpost":["cart"],"checkout\/cart\/estimatepost":["cart"],"checkout\/cart\/estimateupdatepost":["cart"],"checkout\/onepage\/saveorder":["cart","checkout-data","last-ordered-items"],"checkout\/sidebar\/removeitem":["cart"],"checkout\/sidebar\/updateitemqty":["cart"],"rest\/*\/v1\/carts\/*\/payment-information":["cart","last-ordered-items","instant-purchase"],"rest\/*\/v1\/guest-carts\/*\/payment-information":["cart"],"rest\/*\/v1\/guest-carts\/*\/selected-payment-method":["cart","checkout-data"],"rest\/*\/v1\/carts\/*\/selected-payment-method":["cart","checkout-data","instant-purchase"],"customer\/address\/*":["instant-purchase"],"customer\/account\/*":["instant-purchase"],"vault\/cards\/deleteaction":["instant-purchase"],"multishipping\/checkout\/overviewpost":["cart"],"authorizenet\/directpost_payment\/place":["cart","checkout-data"],"paypal\/express\/placeorder":["cart","checkout-data"],"paypal\/payflowexpress\/placeorder":["cart","checkout-data"],"paypal\/express\/onauthorization":["cart","checkout-data"],"persistent\/index\/unsetcookie":["persistent"],"review\/product\/post":["review"],"braintree\/paypal\/placeorder":["cart","checkout-data"],"wishlist\/index\/add":["wishlist"],"wishlist\/index\/remove":["wishlist"],"wishlist\/index\/updateitemoptions":["wishlist"],"wishlist\/index\/update":["wishlist"],"wishlist\/index\/cart":["wishlist","cart"],"wishlist\/index\/fromcart":["wishlist","cart"],"wishlist\/index\/allcart":["wishlist","cart"],"wishlist\/shared\/allcart":["wishlist","cart"],"wishlist\/shared\/cart":["cart"]},
                "clientSideSections": ["checkout-data","cart-data","chatData"],
                "baseUrls": ["https:\/\/ambiant.nl\/catalogus\/"],
                "sectionNames": ["messages","customer","compare-products","last-ordered-items","cart","directory-data","captcha","instant-purchase","persistent","review","wishlist","chatData","recently_viewed_product","recently_compared_product","product_data_storage","paypal-billing-agreement"]            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/customer-data": {
                "sectionLoadUrl": "https\u003A\u002F\u002Fambiant.nl\u002Fcatalogus\u002Fcustomer\u002Fsection\u002Fload\u002F",
                "expirableSectionLifetime": 60,
                "expirableSectionNames": ["cart","persistent"],
                "cookieLifeTime": "3600",
                "updateSessionUrl": "https\u003A\u002F\u002Fambiant.nl\u002Fcatalogus\u002Fcustomer\u002Faccount\u002FupdateSession\u002F"
            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/invalidation-processor": {
                "invalidationRules": {
                    "website-rule": {
                        "Magento_Customer/js/invalidation-rules/website-rule": {
                            "scopeConfig": {
                                "websiteId": "1"
                            }
                        }
                    }
                }
            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "body": {
            "pageCache": {"url":"https:\/\/ambiant.nl\/catalogus\/page_cache\/block\/render\/","handles":["default","cms_noroute_index","cms_page_view","cms_noroute_index_id_no-route"],"originalRequest":{"route":"cms","controller":"noroute","action":"index","uri":"\/catalogus\/catalogsearch\/result\/index.php"},"versionCookieName":"private_content_version"}        }
    }
</script>

<script>
	function _SmQuickView(){
		var $ = (typeof $ !== 'undefined') ? $ : jQuery.noConflict();
		var	pathbase = 'quickview/index/index',
			_item_cls = $('.product-items li.product-item .product-item-info .product-item-details'),
			_item_cls_show_button = $('.product-items li.product-item'),
			_base_url = 'https://ambiant.nl/catalogus/';
		var baseUrl = _base_url + pathbase;
		var _arr = [];
		if(_item_cls.length > 0 && _item_cls_show_button.length > 0){
			_item_cls.each(function() {
				var $this = $(this);
				if($this.parent().parent().find("a.sm_quickview_handler").length <= 0) {
					if( $this.find('a').length > 0 ){
						var _href =	(typeof $($this.find('a')[0]).attr('href') !== 'undefined' && $($this.find('a')[0]).attr('href').replace(_base_url,"") == '#') ? $($this.parent().find('a')[0]) : $($this.find('a')[0]);
						if(typeof _href.attr('href') !== 'undefined'){
							var	producturlpath = _href.attr('href').replace(_base_url,"");
							producturlpath = ( producturlpath.indexOf('index.php') >= 0 ) ? producturlpath.replace('index.php/','') : producturlpath;
							var	reloadurl = baseUrl+ ("/path/"+producturlpath).replace(/\/\//g,"/"),
								_quickviewbutton = "<a class='sm_quickview_handler btn-action' title='Quick View' href='"+reloadurl+"'></a>";
							_arr.push(_quickviewbutton);
						}
					}
				}
			});
			var count = 0 ;
			_item_cls_show_button.each(function () {
				if(typeof _arr[count] != 'undefined' && $(this).find("a.sm_quickview_handler").length <= 0)
				{
					$(this).append(_arr[count]);
					count ++;
				}
			});
			_SmFancyboxView();
		}
	}

	function _SmFancyboxView(){
		var $ = (typeof $ !== 'undefined') ? $ : jQuery.noConflict();
		$('.sm_quickview_handler').fancybox({
						autoSize       :  1,
			title          : 'null',
			scrolling      : 'auto',
			type           : 'ajax',
			ajax :{
				dataType : 'json',
				headers  : { 'X-fancyBox': true }

			},
			openEffect     : 'elastic',
			closeEffect    : 'elastic',
			helpers        :{
				title:  null,
								overlay : {
					showEarly : true
				}
							},
			beforeLoad: function(){

			},
			afterLoad:function(){
				var _current =  'https://ambiant.nl/catalogus/catalogsearch/result/index.php';
				// if(typeof $('.fotorama-item').data('fotorama') !== 'undefined'){
				// 	$('.fotorama-item').data('fotorama').destroy();
				// 	$('.fotorama-item').remove();
				// }
				if(typeof this.content.sucess !== 'undefined' && this.content.sucess == true){
					var _title = '<div class="smqv-title"><h1>'+this.content.title+'</h1></div>', _content = this.content.item_mark ;
					this.inner.html('<div id="sm_quickview" class="sm-quickview">'+_title+_content+'</div>');

					$('#sm_quickview .action.tocompare').on('click', function(e){
						setTimeout(function(){
							window.location.href = _current;
						},1000);
					});
				}
			},
			beforeShow : function(){
				var _bundle_slide	=  $('#bundle-slide');
				if(_bundle_slide.length){
					_bundle_slide.on('click', function(){
						$('.fancybox-inner').addClass('smqv-height-content');
						var  _bundleOptionsContainer = $('.bundle-options-container .product-add-form');
						_bundleOptionsContainer.show();
						$('html, body, .fancybox-wrap').animate({
							scrollTop: _bundleOptionsContainer.offset().top
						}, 600);
					});
				}

			},
			afterShow : function(){
				if($('#quickview-gallery-placeholder').length){
					$('#quickview-gallery-placeholder').removeClass('gallery-loading');
				}
				
				
			},
			beforeChange: function(){

			},
			beforeClose: function(){
				// if(typeof $('.fotorama-item').data('fotorama') !== 'undefined'){
				// 	$('.fotorama-item').css({'display':'none'}).clone().appendTo('body');
				// 	$('.fotorama-item').data('fotorama',$('.fotorama-item').data('fotorama'));
				// }
			},
			afterClose:function(){

			}
		});
	}
</script>


<script type="text/javascript">
	//<![CDATA[
	require(['jquery','jqueryfancyboxpack'], function ($) {
		setTimeout(function(){ _SmQuickView(); }, 1000);
	});
	//]]>
</script><dl>
<dt>The page you requested was not found, and we have a fine guess why.</dt>
<dd>
<ul class="disc">
<li>If you typed the URL directly, please make sure the spelling is correct.</li>
<li>If you clicked on a link to get here, the link is outdated.</li>
</ul></dd>
</dl>
<dl>
<dt>What can you do?</dt>
<dd>Have no fear, help is near! There are many ways you can get back on track with Magento Store.</dd>
<dd>
<ul class="disc">
<li><a href="#" onclick="history.go(-1); return false;">Go back</a> to the previous page.</li>
<li>Use the search bar at the top of the page to search for your products.</li>
<li>Follow these links to get you back on track!<br /><a href="https://ambiant.nl/catalogus/">Store Home</a> <span class="separator">|</span> <a href="https://ambiant.nl/catalogus/customer/account/">My Account</a></li></ul></dd></dl>
</div></div><div id="ytech_right" class="col-lg-3 col-md-3"><div class="sidebar sidebar-additional"><div class="block block-compare" data-bind="scope: 'compareProducts'" data-role="compare-products-sidebar">
    <div class="block-title">
        <strong id="block-compare-heading" role="heading" aria-level="2">Producten vergelijken</strong>
        <span class="counter qty no-display" data-bind="text: compareProducts().countCaption, css: {'no-display': !compareProducts().count}"></span>
    </div>
    <!-- ko if: compareProducts().count -->
    <div class="block-content no-display" aria-labelledby="block-compare-heading" data-bind="css: {'no-display': !compareProducts().count}">
        <ol id="compare-items" class="product-items product-items-names" data-bind="foreach: compareProducts().items">
                <li class="product-item">
                    <input type="hidden" class="compare-item-id" data-bind="value: id"/>
                    <strong class="product-item-name">
                        <a data-bind="attr: {href: product_url}, html: name" class="product-item-link"></a>
                    </strong>
                    <a href="#"
                       data-bind="attr: {'data-post': remove_url}"
                       title="Verwijder&#x20;dit&#x20;artikel"
                       class="action delete">
                        <span>Verwijder dit artikel</span>
                    </a>
                </li>
        </ol>
        <div class="actions-toolbar">
            <div class="primary">
                <a data-bind="attr: {'href': compareProducts().listUrl}" class="action compare primary"><span>Vergelijken</span></a>
            </div>
            <div class="secondary">
                <a id="compare-clear-all" href="#" class="action clear" data-post="{&quot;action&quot;:&quot;https:\/\/ambiant.nl\/catalogus\/catalog\/product_compare\/clear\/&quot;,&quot;data&quot;:{&quot;uenc&quot;:&quot;&quot;,&quot;confirmation&quot;:true,&quot;confirmationMessage&quot;:&quot;Weet u zeker dat u dit product wilt verwijderen van uw vergelijking?&quot;}}">
                    <span>Alles verwijderen</span>
                </a>
            </div>
        </div>
    </div>
    <!-- /ko -->
    <!-- ko ifnot: compareProducts().count -->
    <div class="empty">Geen producten geselecteerd.</div>
    <!-- /ko -->
</div>
<script type="text/x-magento-init">
{"[data-role=compare-products-sidebar]": {"Magento_Ui/js/core/app": {"components":{"compareProducts":{"component":"Magento_Catalog\/js\/view\/compare-products"}}}}}
</script>
</div></div></div></div></div></main><footer class="page-footer"><div class="footer footer-wrapper">
	<footer>

    <section class="link-block">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-4">
                    <!-- Site logo and social Link-->
                    

    

    
            <div class="social-wrap">
        <a class="logo-wrap" href="https://ambiant.nl/">
            <img src="https://ambiant.nl/application/files/6115/6956/6156/Logo-ambiant.jpg" class="img-responsive" alt="Logo"/>
        </a>
                <div class="block block-social">
            <h4 class="block-title">Volg ons</h4>
            <ul class="information">
                                                                                    <li><a href="https://www.instagram.com/ambiant.official/"target="_blank">
                            <img src="/application/themes/ambiant/images/instagram.svg" alt="Instagram">
                        </a></li>
                                                    <li><a href="https://nl.pinterest.com/cotapnl/"target="_blank">
                            <img src="/application/themes/ambiant/images/pinterest.svg" alt="Pinterest">
                        </a></li>
                
                                    <li><a href=" https://www.linkedin.com/company/10261734"target="_blank">
                            <img style="width:22px; height: 22px;" src="/application/themes/ambiant/images/linkedin.svg" alt="Pinterest">
                        </a></li>
                            </ul>
        </div>
            </div>
    



                    <!-- /Site logo-->
                </div>
                <div class="col-sm-12 col-md-4">
                    <!-- Newsletter -->
                    

        <div class="ccm-custom-style-container ccm-custom-style-main-168710" >
    <!-- Landing-btn -->
    <a class="btn-landing" href="https://ambiant.nl/nieuwsbrief/" target="">
        Schrijf je hier in voor de nieuwsbrief    </a>
<!-- /Landing-btn -->
    </div>


    
<div id="HTMLBlock164381" class="HTMLBlock">
<font size="1;">This site is protected by reCAPTCHA and the Google <a href="https://policies.google.com/privacy">Privacy Policy</a> and <a href="https://policies.google.com/terms">Terms of Service</a> apply.</font></div>
                    <!-- /Newsletter -->
                </div>
                <div class="col-sm-12 col-md-2 col-md-offset-1">
                    <!-- Footer menu -->
                    

        <address class="block block-contact-list" itemscope itemtype="http://schema.org/Organization">
        <ul class="block block-links">
            <li itemprop="streetAddress"> </li>
            <li itemprop="postalCode"></li>
            <li itemprop="addressLocality"></li>
            <li class="separator"></li>
            <li itemprop="telephone"></li>
        </ul>
    </address>
    
                    <!-- /Footer menu -->
                </div>
            </div>
        </div>
    </section>

    <section class="copy-block">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul class="footer-copyright">
                        <li>
                            &copy; 2020 ambiant.nl
                        </li>
                        <li>
                            

    

    

<ul class="list-inline">
    </ul>


                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

</footer>
<!-- /FOOTER --></div></footer><script type="text/x-magento-init">
        {
            "*": {
                "Magento_Ui/js/core/app": {
                    "components": {
                        "storage-manager": {
                            "component": "Magento_Catalog/js/storage-manager",
                            "appendTo": "",
                            "storagesConfiguration" : {"recently_viewed_product":{"requestConfig":{"syncUrl":"https:\/\/ambiant.nl\/catalogus\/catalog\/product\/frontend_action_synchronize\/"},"lifetime":"1000","allowToSendRequest":null},"recently_compared_product":{"requestConfig":{"syncUrl":"https:\/\/ambiant.nl\/catalogus\/catalog\/product\/frontend_action_synchronize\/"},"lifetime":"1000","allowToSendRequest":null},"product_data_storage":{"updateRequestConfig":{"url":"https:\/\/ambiant.nl\/catalogus\/rest\/default\/V1\/products-render-info"},"requestConfig":{"syncUrl":"https:\/\/ambiant.nl\/catalogus\/catalog\/product\/frontend_action_synchronize\/"},"allowToSendRequest":null}}                        }
                    }
                }
            }
        }
</script>
</div>    </body>
</html>
